
To build the last version of conauto, execute:
	$ make

To build the intermediate versions, execute:
	$ ./versionsMaker.sh

